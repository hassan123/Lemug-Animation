describe('basics', function() {

  it('creates a global modernizr object', function() {
    expect(Modernizr).to.not.be(undefined);
  });

});
