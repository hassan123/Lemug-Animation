[![CDNJS](https://img.shields.io/cdnjs/v/ajaxify.svg)](https://cdnjs.com/libraries/ajaxify)

For extensive documentation and live demo, please refer to: [Ajaxify @4nf.org](http://4nf.org/ajaxify-overview/)
