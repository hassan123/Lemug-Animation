window.LiveReloadOptions = { host: 'localhost' };
require('../../../lib/startup.js');

window.hellow = function hellow() {
    return 42;
}
